# [@CoderElijah](https://replit.com/@CoderElijah)'s Final Comment:

I am here to make my final Replit comment. I will miss comments. I am very highly strongly opposed to the removal of comments from Repls. RIP Replit comments. We love you dearly and will miss you from the bottom of our hearts. 😭