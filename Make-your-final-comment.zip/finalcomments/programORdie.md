# [@programORdie](https://replit.com/@programORdie)'s Final Comment:

Again another dumb move of replit.
After stopping free hosting, you kill your community by removing comments.
This is just sick, replit is not only coding, its also about collaboration and help, that you can get with these comments.
Replit is really changing to one of those hosting platforms with way to high prices everybody hates, instead of the cool free community it was first.