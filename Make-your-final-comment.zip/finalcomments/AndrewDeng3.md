# [@AndrewDeng3](https://replit.com/@AndrewDeng3)'s Final Comment:

"all centered around making it easier to share and explore code."

Really replit? I mean seriously. Comments are all about sharing and exploring code!!! And you can ask for help without needing to pay for bounties

# Also posted

u0d9e
u1f595
you arent a coder if you dont know this

The person below me speaks the truth \[EDIT: [@MrVoo](https://replit.com/@MrVoo)\]

pikachub2005, bigminiboss, techwithanirudh, and overdrivereplit have all made chat repls. Check them out!

prob moving back to scratch cuz comments are getting removed

[@KongJiaWei](https://replit.com/@KongJiaWei]) i paid for core with my own money from doing chores so don't talk about money. however, I agree with comments