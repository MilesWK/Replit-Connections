# [@SharkNUb](https://replit.com/@SharkNUb)'s Final Comment:

how im I supposed to get feedback from da people, REPLIT?