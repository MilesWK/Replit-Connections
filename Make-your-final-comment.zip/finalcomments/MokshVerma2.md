# [@MokshVerma2](https://replit.com/@MokshVerma2)'s Final Comment:

Well, it’s the end. I really hope replit doesn’t make the hosting changes and comment changes permanent.