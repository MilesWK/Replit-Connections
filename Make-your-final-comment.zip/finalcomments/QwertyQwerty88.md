# [@QwertyQwerty88](https://replit.com/@QwertyQwerty88)'s Final Comment:

rip replit

# Also posted:
[@python660](https://replit.com/@python660) I'm honored to be the first name you thought of. good luck with your codng journey my friend tho, you'll still be on amc, no?