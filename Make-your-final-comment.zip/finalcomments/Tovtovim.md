# [@Tovtovim](https://replit.com/@Tovtovim)'s Final Comment:
![see images/Tovtovim.jpg](../images/Tovtovim.jpg)

# Also Posted:
[@PianoMan0](https://replit.com/@PianoMan0) That was what I was thinking earlier! But that means that it would be server-side, and server-side repls would take a lot of resources