# [@GiggaPoggers](https://replit.com/@GiggaPoggers)'s Final Comment:

goodbye only part of Replit I enjoyed

btw congrats on 420 followers

# Comment posted after

loved it when I could hop on and just comment on everything, thats actually why I know [@CoderElijah](https://replit.com/@CoderElijah), it makes me sad Replit chose to just destroy everything, as if the community didn’t hate them enough.