# [@IRONCL4D-playing](https://replit.com/@IRONCL4D-playing)'s Final Comment:

Replit is an interesting place. Although I haven't been on the site for as long as some, I consider myself part of the community, which I am grateful to have been a part of. It has been a very fun time making and posting games. I don't know why, maybe they are following in unity's business plan, but I hope replit can return to the site it once was, not payed and not laggy, a place where you could get lost in the lore of some random text game in minutes. It saddens me that this is happening, but it is, and I will be leaving replit. Its been a good time.

-IRONCL4D-playing