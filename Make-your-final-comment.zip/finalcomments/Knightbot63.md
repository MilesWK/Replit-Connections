# [@Knightbot63](https://replit.com/@Knightbot63)'s Final Comment:

They're really being removed? That's really disappointing to start 2024 on replit.

# Comment posted after:
Also, this is my actual final comment. goodbye replit comments.