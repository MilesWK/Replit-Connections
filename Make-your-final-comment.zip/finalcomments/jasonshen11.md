# [@jasonshen11](https://replit.com/@jasonshen11)'s Final Comment:

rip replit comments

# Comment posted after

watching people argue on the realmz.io replit page was so much fun

I swear if publishing free gets removed I'm actually gonna be so mad