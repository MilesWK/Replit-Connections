# [@Grimaceamong](https://replit.com/@Grimaceamong)'s Final Comment:

Replit is ruining itself no one wants an AI platform we want a platform to code