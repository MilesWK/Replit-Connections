# [@ProximaAtlas](https://replit.com/@ProximaAtlas)'s Final Comment:

Replit is doing a serious injustice to EVERYONE by removing comments; Replit Community was a place to share and receive feedback. I hope, someday, the comments will return. Until then, all Replit is is a fancy IDE, nothing more. I remember the days when Replit was repl.it and it was made of more goodwill than hungry greediness and desire to earn money.
Save your projects and leave Replit; flood them with requests to turn Replit back into the wonderful thing it once was.

Vismai Nair
Formerly active user of Replit
Advocate for Community