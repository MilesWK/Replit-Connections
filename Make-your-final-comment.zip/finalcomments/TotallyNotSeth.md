# [@TotallyNotSeth](https://replit.com/@TotallyNotSeth)'s Final Comment:

replit community after they are silenced by the people benefiting from said community:

(they all vanish)