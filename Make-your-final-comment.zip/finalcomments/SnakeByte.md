# [@SnakeByte](https://replit.com/@SnakeByte)'s Final Comment:

So sad comments are being removed, why is Replit even doing this??