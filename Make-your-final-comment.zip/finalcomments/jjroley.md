# [@jjroley](https://replit.com/@jjroley)'s Final Comment:

Wait comments too? Sad, Replit is changing from an amazing community to an average hosting platform with an admittedly cool online IDE yet not feasible for real-world projects, and higher-than-average prices. I'm grateful for the free hosting there was while it existed but sad to see it go.