# [@PikachuB2005](https://replit.com/@PikachuB2005)'s Final Comment:

My favorite part of this website was always it's community

But with each change to it (talk being removed, the discord server becoming unofficial, and now comments being removed) there isn't really a nice place to go anymore.

I joined when Repl Talk still existed, and I was really upset when it was removed. It may be mostly because of the smaller userbase, but I feel like the trending projects back then were (mostly) higher quality. The comments, believe it or not, used to give feedback and constructive criticism relevant to the project itself. There used to be an entire category to posts dedicated to asking questions, and other users would try to help you. Then you could mark a comment as the answer, helping anyone else who has the same issue. This is why I've started making my own version of Repl Talk. I want to bring that community back. I will hopefully be publishing the repl by the end of the week, giving everyone a chance to actually talk again. I won't be able to do this alone though- I'll need some voluntary moderators, depending on how used it is.

![see images/PikachuB2005.jpg](../images/PikachuB2005.jpg)
To Replit staff: Currently, the website uses the name Repl Talk, your UI elements, and your default themes. I will be making it a repl extension as an excuse to keep them (I'm not great at frontend lol) but if you'd like me to change anything let me know. I will be giving visible credit on the site.