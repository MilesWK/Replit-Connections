# [@kaycering26](https://replit.com/@kaycering26)'s Final Comment:

[@Lockcbah2](https://replit.com/@Lockcbah2) replit aint getting removed