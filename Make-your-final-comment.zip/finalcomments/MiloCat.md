# [@MiloCat](https://replit.com/@MiloCat)'s Final Comment:

Goodbye the >50million comments
The good old days when I tried to request all of them one by one and replit staff got mad at me 🥹