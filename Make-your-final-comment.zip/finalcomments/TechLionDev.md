# [@TechLionDev](https://replit.com/@TechLionDev)'s Final Comment:

Replit Gets Worse By The Hour, Like if this is supposed to be what DEV feels like, I'm going to law school. :/