# [@xfinitywebdev](https://replit.com/@xfinitywebdev)'s Final Comment:

Yeah, goodbye everyone, goodbye replit