# [@KongJiaWei](https://replit.com/@KongJiaWei)'s Final Comment:

Bye, replit comments :(, you know, replit just isn't the same anymore :(

# Also posted:

But what bothers me the most, is how hypocritical and coward-ic replit is, every repl against the updates is banned, along with the creator. And they keep turning a blind eye to their affect on the community. I swear, they're acting like the mayor of San Francisco right now, this really needs to change

Nobody: Replit: I heard people are typing weird things into the comments, so instead of taking 1 single day to add a filter system, were just gonna remove comments just cuz we can, because we don't care anything about the community and because it saves us a few hours of work. Oh and we'll also add 30 more micro-transactions so that we can milk money out of people who have rich daddies. And plus, comments don't do anything, right, it's not like they were sources of support, recommendation/fed-back, and communication in general. So now I'm sitting here doing, damn who knows. Wondering why so many people are leaving. WhAT A Big MysTERy. Oh look at that, someone just completed a bounty and now has $100 worth of cycles,
$100 worth of cycles I can use >:)

I mean, we can feature request it, so maybe if replit doesn't act like a total Hypocrit and Coward then it may be accepted.

Especially if multipule people spam the sugestion

All I can really say is 去你的 replit for ruining everyone's experience, thanks for the sour new year. (Even though I don't celebrate holidays)

It mean F*** you, not everything in Chinese directly means it translation you know, the exact translation of the phrase for being fired is "Wrap up", or something around those lines.