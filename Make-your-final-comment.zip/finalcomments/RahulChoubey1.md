# [@RahulChoubey1](https://replit.com/@RahulChoubey1)'s Final Comment:

goodbye, comments…
I found comments to be a great social sharing tool. For example, games on Replit had people comment their top score, and go "wow! that's cool!" As someone who decided to leave Discord, it's sad to see another communication option gone. GitHub is great, but it doesn't have the execute feature. Replit was that execute feature.

I was here in the repl.it days as well, and I'm still nostalgic for the old cycle system (the karma system). My 273 cycles will probably stick with my account forever.

I might have to find a new IDE.

# Also posted:

[@PianoMan0](https://replit.com/@PianoMan0) Essentially, Cycles used to be a karma system where getting upvotes and whatnot would earn Cycles, quite like with reputation on Stack Exchange. However, with the new Cycles-currency system, they migrated all the old karma into Cycles, which is where my 273 came from.