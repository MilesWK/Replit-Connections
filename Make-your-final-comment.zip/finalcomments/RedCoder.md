# [@RedCoder](https://replit.com/@RedCoder)'s Final Comment:

[@python660](https://replit.com/@python660) It makes me happy to be on that list. I don’t think Replit is gone forever, but it is certainly going through many terrible changes. I hope that Replit will decide to change its ways one day