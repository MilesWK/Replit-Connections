# [@ethanSol7](https://replit.com/@ethanSol7)'s Final Comment:

goodbye comments :C