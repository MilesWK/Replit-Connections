# [@sonicx180](https://replit.com/@sonicx180)'s Final Comment:

Replit isnt that bad