# [@bigminiboss](https://replit.com/@bigminiboss)'s ~~Final~~ Comment:
loved replit but some descisions went sour along the way hope we can get on the right path again cheers

# [@bigminiboss](https://replit.com/@bigminiboss)'s Actual Final Comment:
[@PikachuB2005](https://replit.com/@PikachuB2005) final comment: :this: lmao

# Comments posted after (why):
[@MrVoo](@MrVoo) it became the very thing it hated

oh forgotti to mention: replit used to be a fun indie space where people just posted projects that they wanted to post after taking a lot of time to create it (also, it wasn't all edu there were a lot more high end projects that weren't ai smh). Moreover, it used to be a bit of a community if you will, it listened to feedback and took it somewhat to heart. Finally, it was just really flipping convenient and a nice place to host for free. However, corporate stuff ig, like ik you gotta pay the bills but perhaps more bills would come in if you listened to ppl and what they wanted idk