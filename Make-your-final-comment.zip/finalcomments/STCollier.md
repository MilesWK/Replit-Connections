# [@STCollier](https://replit.com/@STCollier)'s Final Comment:

Dang, Replit just keeps getting worse. It's kinda crazy (and like MrVoo said, almost impressive somehow-) that Replit keeps managing to destroy their platform more and more.