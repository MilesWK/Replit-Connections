# [@IndaLin](https://replit.com/@IndaLin)'s Final Comment:

Ｉthink I will leave replit soon

# Comments posted after
because the update are stupid