# [@SalladShooter](https://replit.com/@SalladShooter)'s Final Comment:

[@PikachuB2005](https://replit.com/@PikachuB2005) yeah the community was great. I will be excited to see this new version of Repl talk.