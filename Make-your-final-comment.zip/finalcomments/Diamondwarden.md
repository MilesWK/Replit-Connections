# [@Diamondwarden](https://replit.com/@Diamondwarden)'s Final Comment:

bro comments are getting removed
that's crazy