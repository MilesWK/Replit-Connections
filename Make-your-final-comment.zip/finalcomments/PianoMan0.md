# [@PianoMan0](https://replit.com/@PianoMan0)'s Final Comment:

This is my final comment. Comments were misused sometimes, but most of the time it was used to give constructive feedback. I'm not sure why [@replit](https://replit.com/@replit) decided to stop them. This update will definitely bring down my use of Replit. Anyway, saddest new year ever. Bye.

# Also posted

Final Comment For Real.

You know that a Replit hates an update when the top 2 trending repls are about it.

I had an idea that could (somewhat) keep comments alive. Make a little bit of code that users can fork and add to their repls. It would make a button on the side of the screen and when you click on it, it opens a mini comments section for the repl. I know some php, so that could help, but I would need to work with someone with a bit more knowledge on this kind of thing. Anyone want to help?

[@RahulChoubey1](https://replit.com/@RahulChoubey1) what was the karma system?

[@RahulChoubey1](https://replit.com/@RahulChoubey1) That seems like a really cool system. I understand why you miss it. I got here right when they had moved to cycles so I never saw it.