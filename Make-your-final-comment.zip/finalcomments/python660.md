# [@python660](https://replit.com/@python660)'s Final Comment:

Dear Replit,

"We" have existed since the very beginning, when you proudly boasted your nametag with repl.it scribbled on it, when repls were a source of creativity, when users could log on to Replit and see new, innovative, and original projects, games, and websites, each with their own element which made them unique. And that was in the time when Replit was a synonym not for AI, but for an extremely friendly community and a simple idea-to-project flow which allowed users to code whatever they wanted without being limited by your own hardware or annoying errors when the Python installer just doesn't seem to work.

# That was when Replit was made for us.
And those moments begin to fade away, being pushed into the black hole of the past, being replaced by what was labeled as progressive change, change that leaves us stranded in a used-to-be programming haven, changes that steer Replit towards its imminent failure.

It could have been better, it didn't have to end like this. But for now, and just like how Replit is a synonym for AI, "we" is just another excuse, another empty promise, another backstabbing word...

# Soon.
What used to be so "Soon" that an entire [subdomain](https://devday.replit.com/) for, was now Never.

And as we part ways, I leave this final note in hopes for a better Replit.

Farewell, Replit.

--------

PS: CHECK THIS OUT: [https://replit.com/@python660/The-Story-of-Replit](https://replit.com/@python660/The-Story-of-Replit)

# Also Posted

This is truly farewell...

Btw \[EDIT: I'm not making all of those hyperlinks, also why is my name spelt wrong ;-;\] @QwertyQwerty88 @Classified3D @Classified4D @AndrewDeng3 @CoderShayan @CoderElijah @9pfs @doxr @OmegaOrbitals @SalladShooter @Firepup650 @bigminiboss @techwithanirudh @RedCoder @cldprv @bobastley @Idkwhttph @SnakeByte @Classfied3D @SnakeyKing @GiggaPoggers @JayAySeaOhBee14 @PikachuB2005 @MiloCat @codingMASTER398 @not-ethan

I'm in your walls lol

---

Thank you to the above people and anyone who stumbles upon this comment for making my experience in the Replit Community as memorable as possible.

[@Classfied4D](https://replit.com/@Classfied4D) oh i guess my browser failed me once again...

[@Classfied4D](https://replit.com/@Classfied4D) ok just wrote one, took like 30 minutes. Would you mind updating the python660.md file? pwetty pwease?

[@PikachuB2005](https://replit.com/@PikachuB2005) Farewell, replit. Also, your repl likes viewer is gone, why?

[@RedCoder](https://replit.com/@RedCoder) thank you for those kind words!

---
Hehe, i changed my replit name :nefarious: