# [@BluestNebula](https://replit.com/@BluestNebula)'s Final Comment:

bro comments are getting removed
that's crazy