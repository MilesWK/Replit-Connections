# [@NicholasWilkin4](https://replit.com/@NicholasWilkin4)'s Final Comment:

Removing comments is pointless and stupid