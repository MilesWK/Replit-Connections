# [@coolioyoutuber](https://replit.com/@coolioyoutuber)'s Final Comment:

goodbye replit, i will quit as an avid programmer and work on youtube more often