# [@MilesWK](https://replit.com/@MilesWK)'s Final Comment:

I just feel so sad. I liked replit community. This will feel like a dark cave almost with code. The moderation team will not be needed much.

Replit was unique. They had community, and glitch doesn't have that fun part. The ask forums aren't the same. This offers more than just questions. It allows new doors to open.

I think once/if replit actually goes through with that decision, there will be nothing left that is special about replit. There might be a few things here and there such as how many programming languages there are available, and how you can share all those. But the community is probably one of the best parts about this place.

[@replit](https://replit.com/@replit) : I was soooo close to leaving replit. And I might if I hate the comment removal. I think hosting changes was going to be bad enough, now this? I don't know why you are doing this, and there might be a GREAT reason, but I think this could be one of the worst decisions as a business.

Goodbye comments. Maybe you will come back, and maybe, just maybe, you won't go.

[@Classfied3D](https://replit.com/@Classfied3D) thank you for making this project. This feels like such a solemn event to kick off 2024.

-MilesWK

# Comments posted after

[@SalladShooter](https://replit.com/@SalladShooter) [@bigminiboss](https://replit.com/@bigminiboss) [@PikachuB2005](https://replit.com/@PikachuB2005) Happy new year: from replit