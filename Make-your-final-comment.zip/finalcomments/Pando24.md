# [@Pando24](https://replit.com/@Pando24)'s Final Comment:

Comments Revolution!!

# Also Posted

[@Brofiop](https://replit.com/@Brofiop) very true. Im considering moving operations to Glitch.