# [@Reykr](https://replit.com/@Reykr)'s Final Comment:

Goodbye, Replit Comments.
Time to move to [Itch.io](https://reykr.itch.io/). ✌