# Goodbye everyone

Replit has finally removed comments, but someone (who wishes to stay anonymous) has managed to recover them and contact me on discord (my username: Classfied3D). In total, there are exactly 100 people who made their last comment(s). You can find each and everyone of them in the `finalcomments` folder. Forking & Running the repl runs a bash script that displays a random one after pressing enter.

# I still want to comment/be part of the community

There are still some ways to do this:
* [@PikachuB2005](https://replit.com/@PikachuB2005) is almost finished on a remake on repl talk (this was what was used before comments were added in the first place). I would go check him out! (You can talk about progress on FoR [here](https://discord.com/channels/437048931827056642/1188969918130045001))
* [Friends of Replit](https://discord.gg/FriendsOfReplit) is a discord server (the OG one) originally created by replit and now unofficial. It's very active and probably the best place to be part of the community!
* [AMC](https://amcforum.wiki/) is an unoffical discourse server with a lot of the members of the community and is active (hence the name **A**ctive **M**ember **C**hat). It isn't entirely about replit, but replit takes up the biggest chunk of it (compared to other services)
* [Ask](https://ask.replit.com/) is an offical discourse server ('for the replit community to ask and answer questions') for replit. It's mainly a Q&A hub for replits customers, but a small community exists there as well. You'll also find updates about replit and get messages from staff first!