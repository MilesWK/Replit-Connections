commentcount=$(ls -1q finalcomments | wc -l)
echo "Comments will be entirely removed sometime today or tommorow. Make your final comment here. The blog post: https://blog.replit.com/social-updates. They said they would begin in 2024, and free hosting will be discontinued on 1 Jan 2024, meaning it is likely we will see these changes very soon (the staff have been on holiday, so it wont happen immediately). Press enter to show a random comment (out of $commentcount)."

cd finalcomments

text=$(echo -e "Press [Enter] to view a random final comment")

# Calculate the center of the terminal for the text
row=$(($(tput lines) - 2))
col=$((($(tput cols) - ${#text}) / 2))

# Print the text at the calculated center
tput cup "$row" "$col"
echo -e "\033[48;2;255;255;255m" "$text" "\033[0m"

while true
  do
    read -p ""
    sleep .5
    tput clear
    
    file=$(ls | shuf -n 1 | xargs -0 echo)
    md=$(pandoc -t plain --columns="$(tput cols)" "$file")
    
    # Calculate the center of the terminal for the text
    row=$(($(tput lines) - 2))
    col=$((($(tput cols) - ${#text}) / 2))

    # Print the text at the calculated center
    echo "$md"
    tput cup "$row" "$col"
    echo -e "\033[48;2;255;255;255m" "$text" "\033[0m"
    sleep .5

  done